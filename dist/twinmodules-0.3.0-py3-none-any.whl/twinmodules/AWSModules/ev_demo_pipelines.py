#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Nov 18 12:54:40 2022

@author: ubuntu
"""

import requests
import kfp
import kfp.dsl as dsl
import kfp.components as comp
from tqdm import tqdm
import glob
import os
import json

import ev_demo_functions as edf


HOST = "http://localhost:8080/"
#USERNAME = "admin@kubeflow.org"
USERNAME = "user@example.com"
PASSWORD = "12341234"
#Did I set this during inital setup? I grabbed this from the UI.
#can run "kubectl get profiles" and "kubectl get ns" to get a list
NAMESPACE = "kubeflow-user-example-com"

CLUSTER_NAME  = "mykubeflow"
REGION = "us-east-1"

def connect_kubeflow():
    session = requests.Session()
    response = session.get(HOST)

    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
    }

    data = {"login": USERNAME, "password": PASSWORD}
    session.post(response.url, headers=headers, data=data)
    session_cookie = session.cookies.get_dict()["authservice_session"]

    client = kfp.Client(
        host=f"{HOST}/pipeline",
        cookies=f"authservice_session={session_cookie}",
        namespace=NAMESPACE,
    )

    return client

def clean_dir():
    folders = glob.glob('wd/V*')

    for folder in folders:
        if os.path.isdir(folder):
            os.system('sudo rm -rf {}'.format(folder))




#-----------------------------------pipelines and components



@dsl.pipeline(
	name="calculation pipeline",
	description="A toy pipeline that performs arithmetic calculations."
)
def calculation_pipeline(n_vehicles: int, n_routes: int) -> None:

    data_gen_node = edf.generate_data(n_vehicles, n_routes)

    #folders = glob.glob('wd/V*')
    nFolders = n_routes*n_vehicles

    for i in range(nFolders):
        data_gen_node = edf.build_model(file_ID=i)


#%% main
#-------------------------------------------------------
if __name__ == '__main__':

    client = connect_kubeflow()

    clean_dir()

    #n cars and n routes
    n_vehicles = 5
    n_routes = 2

    data_gen_node = edf.generate_data(n_vehicles, n_routes)

    folders = glob.glob('wd/V*')

    nFolders = len(folders)

    data_gen_node = edf.build_model(file_ID=5)




#%% test batch

#https://docs.aws.amazon.com/batch/latest/userguide/getting-started-eks.html#getting-started-eks-step-3



    #create a namespace
    #enable RBAC
    #create compute environment
    #create a job queue
    #create a job definition
    #submit job
    #process results
    #terminate AWS batch

    batch_namespace = 'batch-namespace'
    #will need to first check if the namespace already exists
    #"kubectl get ns | grep -c  batch-namespace"
    #seems like benign error if it already exists
    #os.system('kubectl create namespace {}'.format(batch_namespace))





    #dump out eks configuration
    eks_config_name = 'eks_conf.json'
    cmd = 'aws eks describe-cluster --name {} > {}'.format(CLUSTER_NAME, eks_config_name)
    os.system(cmd)
    #dump out instance role information
    iam_config_name = 'iam_conf.json'
    cmd = 'aws iam list-instance-profiles > {}'.format( iam_config_name)
    os.system(cmd)

    if os.path.isfile(eks_config_name):
        with open(eks_config_name,'r') as f:
            eks_config = json.load(f)
    else:
        raise ValueError("ERROR: eks json not found.")

    if os.path.isfile(iam_config_name):
         with open(iam_config_name,'r') as f:
             iam_config = json.load(f)
    else:
         raise ValueError("ERROR: iam json not found.")


    #-----------------------------
    #TODO: ok well this is ugly af.  Need to make this more graceful.  Move into python

    arn = eks_config["cluster"]["roleArn"].split('/')[0] \
        + '/AWSServiceRoleForBatch'

    #os.system("export namespace='{}'".format(batch_namespace))
    # os.system("./namesp.sh")
    # os.system("./rbac.sh")
    # os.system("./finalize_namespace.sh")
    # os.system("eksctl create iamidentitymapping --cluster {}".format(CLUSTER_NAME) \
    #           +' --arn "{}"'.format(arn) \
    #           + ' --username aws-batch')
    print("eksctl create iamidentitymapping --cluster {}".format(CLUSTER_NAME) \
               +' --arn "{}"'.format(arn) \
               + ' --username aws-batch')
    #-----------------------------
    # kubectl get configmap -n kube-system aws-auth -o yaml

    #create an AWS batch queue
    with open('batch_template.json','r') as f:
        batch_config = json.load(f)
    #update template from the eks json config
    batch_config['computeEnvironmentName'] = 'TwinFlow_batch_eks'
    batch_config['eksConfiguration']['eksClusterArn'] = eks_config['cluster']['arn']

    #NAMESPACE
    batch_config['eksConfiguration']['kubernetesNamespace'] = batch_namespace
    #batch_config['kubernetesNamespace'] = "batch-space"
    #batch_config['computeResources']['instanceTypes'] = ['t2.xlarge']
    batch_config['computeResources']['instanceTypes'] = ["optimal"]
    batch_config['computeResources']['maxvCpus'] = 500
    batch_config['computeResources']['minvCpus'] = 1
    batch_config['computeResources']['subnets'] = eks_config['cluster']["resourcesVpcConfig"]["subnetIds"]

    batch_config['computeResources']['securityGroupIds'] = \
                eks_config['cluster']["resourcesVpcConfig"]["securityGroupIds"]

    batch_config['computeResources']['instanceRole'] = \
        iam_config['InstanceProfiles'][0]["Arn"]

    #dump config and create batch compute environment
    batch_config_name = "batch-compute-config.json"
    with open(batch_config_name, 'w') as f:
        json.dump(batch_config,f)


    os.system("aws batch create-compute-environment --cli-input-json file:"\
              +"//./{}".format(batch_config_name))

    #need a wait check to ensure this completes first
    import time
    time.sleep(5)

    #create the AWS queue

    queue_config_name = 'batch-eks-job-queue.json'
    queue_config = {}
    queue_config["jobQueueName"] = "my-queue-1"
    queue_config["priority"] = 10
    queue_config["computeEnvironmentOrder"] = \
            [{"order":1,"computeEnvironment":batch_config['computeEnvironmentName']}]
    with open(queue_config_name, 'w') as f:
        json.dump(queue_config,f)
    os.system("aws batch create-job-queue --cli-input-json file:"\
              +"//./{}".format(queue_config_name))


    #create job definition


    #authenticate and push the docker images to ECR, prior to running batch
    #I am doing this manual right now, we can look at automation later

    # account_number = eks_config["cluster"]["roleArn"].split('/')[0]
    # account_number = account_number.split(':')[-2]

    # os.system("aws ecr get-login-password --region region | docker login --username AWS " \
    #     +"--password-stdin {}.dkr.ecr.{}.amazonaws.com".format(account_number, REGION))

    #steps I followed to push docker images to ECR
    #1) aws ecr create-repository --repository-name some_name/<image_name>
    #2) login into the ECR GUI, go to private repos, click the push commands
    #   and follow instructions to push the image up.
    # step 1) is requried for each image


    #TODO: need to programmatically get this value, or going to have to be a user input
    image_name_uri = '873069797454.dkr.ecr.us-east-1.amazonaws.com/public.ecr.aws/s7m8z6n8/model_build_ann:latest'


    cnt =0
    #https://docs.aws.amazon.com/batch/latest/userguide/example-job-definitions.html
#%%

    cnt+=1

    cwd = os.getcwd()
    data_path = cwd+"/wd"

    job_config_name = 'batch-eks-job-definition.json'
    job_config = {}
    job_config["jobDefinitionName"] = "graph_processing_jobs"
    job_config["type"] = "container"
    job_config["eksProperties"] = \
    {
        "podProperties": {
            "hostNetwork":True,
            "containers":
                [
                    {
                        "image": image_name_uri,
                        "command": ["echo","'hello world'", ">", "/wd/myfile.txt"],
                        "resources": {
                                "limits": {
                                        "cpu":"8",
                                        "memory":"5024Mi"
                                        }
                                    },
                        "volumeMounts": [
                            {
                                "mountPath":"/wd",
                                "name": "pod-mount",
                                "readOnly": False
                                }
                            ]
                        }
                    ],
                "volumes":
                    [
                        {
                        "name":"pod-mount",
                        "hostPath":
                            {
                              "path":data_path
                            #"path": "/tmp/wd" #data_path
                            }
                        }
                    ]
            }
        }
    # job_config["jobDefinitions"] = \
    #         {
    #             "containerProperties": {
    #                 # "mountPoints": [
    #                 #     {
    #                 #         "sourceVolume":data_path,
    #                 #         "containerPath": "/wd",
    #                 #         "readOnly": False
    #                 #     }
    #                 # ]
    #             }
    #         }
    #    # ]


    with open(job_config_name, 'w') as f:
        json.dump(job_config,f)
    os.system("aws batch register-job-definition --cli-input-json file:"\
              +"//./{}".format(job_config_name))


    #submit job
    os.system("aws batch submit-job --job-queue {} --job-definition {} --job-name {}".format(
        queue_config["jobQueueName"],job_config["jobDefinitionName"], "graph_job"+str(cnt)))





#%%

    #this needs some actual logic, job queue disable, wait, delete, compute enviornment
    #disable, wait, delete.

    os.system("aws batch update-compute-environment --compute-environment {} --state DISABLED".format( \
                                                       batch_config['computeEnvironmentName']))

    os.system("aws batch delete-compute-environment --compute-environment {}".format( \
                                                       batch_config['computeEnvironmentName']))




