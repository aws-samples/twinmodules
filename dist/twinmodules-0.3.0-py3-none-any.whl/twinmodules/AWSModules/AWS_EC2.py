#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 14 16:29:29 2023

@author: ubuntu
"""


import boto3

def is_public(subnets:list) -> dict:
    ec2 = boto3.client('ec2')

    public_check = {}
    routetables = ec2.describe_route_tables()

    for routeTable in routetables['RouteTables']:
        associations = routeTable['Associations']
        routes = routeTable['Routes']

        for assoc in associations:
            SubnetId = assoc.get('SubnetId', '')

        if SubnetId not in subnets:
            continue

        isPublic = False
        for route in routes:
            GatewayId = route.get('GatewayId', '')
            if GatewayId.startswith('igw-'):
                isPublic = True
        public_check[SubnetId] = isPublic

    print(public_check)
    return public_check